/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rethrowingexceptions;

/**
 *
 * @author student1212
 */
public class RethrowingExceptions {

   public static void main(String args[]) 
{   
       //callmethod  
       try 
    {     
          someMethod();
           
    }       
                   
   // catch exception thrown from some method 
    catch ( Exception exception )
    { 
        System.err.println ( exception.getMessage () + "\n");
        exception.printStackTrace();
    }
     
}
   
   public static void someMethod() throws Exception 
{
    //call someMethod2
    try
    {
          someMethod2();
    }
      //catch Exceptioms thrown from someMethod2 
       catch ( Exception exception2 )
       { 
           
           throw exception2; //rethrow the Exception 
       }
}
       
   // throw Exception back to someMethod
   public static void someMethod2() throws Exception 
   {
       throw new Exception ("Exception thrown in someMethod2");
  
   } // end clas RethrownEceptions 

  }

